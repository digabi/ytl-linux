# AnyDesk Remote Control Client for YTL Linux

## Introduction

This package contains:
* AnyDesk Remote Control client build with Matriculation Examination
  Board security policies
* Simple loader written in Python, which notifies a local user
  about agreements and privacy policies related to AnyDesk client
  software

When suggested by MEB helpdesk (a.k.a. Abitti-tuki) agent the local
user executes the loader and gets notified about legal issues. If
agreed, the loader executes the AnyDesk client.

## Instructions

### Building new AnyDesk package

1. Go to my.anydesk.com > Builds
1. Click the latest build > Options > Copy Build
1. Click the duplicated build (with `-copy` postfix) to edit > Edit
1. Rename build (Build Settings > Build Name)
  * test build: `test-YYYY-MM-DD-BUILDNO`, e.g. `test-2026-02-11-2` (second test build on 2026-02-11)
  * production build `prod-YYYY-MM-DD-BUILDNO`, e.g. `prod-2026-02-11-23`
1. Rename filename (copy Build Name as filename)
1. Edit settings, if necessary
1. Click "Save"

### AnyDesk client

1. Build both `.tar.gz` and `.deb` version of package
1. Make sure the package dependencies have not changed:
    * Show package dependecies: `apt show ./AnyDeskClient.deb`
    * Verify the dependencies in `make-deb.sh` / `ANYDESK_DEPENDENCIES`
1. Copy the updated `AnyDeskClient.tar.gz` to the same folder with `make-deb.sh`
1. Build a new package by executing `make-deb.sh` or `make-deb-docker.sh` if you
   want to make the build in a container

## New releases

Github Actions automatically builds a deb file out of released AnyDesk tarballs. First create an AnyDesk build (see [Building new AnyDesk package](#building-new-anydesk-package)), and then [create a new GitHub release](https://github.com/digabi/anydesk-meb/releases/new). Make sure to _publish_ the release. After a few minutes a deb file will appear on the release page. The deb file can then be included in ytl-linux, see repository for [instructions](https://github.com/digabi/ytl-linux?tab=readme-ov-file#anydesk).
