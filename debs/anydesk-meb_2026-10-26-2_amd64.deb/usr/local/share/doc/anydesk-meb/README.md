# AnyDesk Remote Control Client for YTL Linux

## Introduction

This package contains:
* AnyDesk Remote Control client build with Matriculation Examination Board security policies
* Simple loader written in Python, which notifies a local user about agreements and privacy policies related to AnyDesk client software

When suggested by MEB helpdesk (a.k.a. Abitti-tuki) agent, the local user executes the loader and gets notified about legal issues. If agreed, the loader executes the AnyDesk client.

## Instructions

### Updating AnyDesk

> [!NOTE]
> You need access to the `digabi@ylioppilastutkinto.fi` AnyDesk account to build new versions of the AnyDesk client in their web portal. If you do not explicitly need to update the AnyDesk version itself and have only changed things in this repo, skip ahead to [Publishing new versions of `anydesk-meb`](#publishing-new-versions-of-anydesk-meb).

1. Go to my.anydesk.com > Builds
2. Click the latest build > Options > Copy Build
3. Click the duplicated build (with `-copy` postfix) to edit > Edit
4. Rename build (Build Settings > Build Name)  
  a. test build: `test-YYYY-MM-DD-BUILDNO`, e.g. `test-2026-02-11-2` (second test build on 2026-02-11)  
  b. production build `prod-YYYY-MM-DD-BUILDNO`, e.g. `prod-2026-02-11-23`
5. Rename filename (copy Build Name as filename)
6. Edit settings, if necessary
7. Click "Save"

Then, add the updated builds to this repo:

1. Download both the .deb and .tar.gz versions of the package from AnyDesk
2. Make sure the package dependencies have not changed:  
  a. Show package dependecies: `apt show ./test|prod-YYYY-MM-DD-BUILDNO.deb`  
  b. Verify the dependencies in `make-deb.sh` / `ANYDESK_DEPENDENCIES`
3. Copy the updated `test|prod-YYYY-MM-DD-BUILDNO.tar.gz` to the root of this repo and delete the previous versions

### Building `anydesk-meb` locally

You can build the .deb package locally with `just build`. Production releases are built with GitHub Actions.

### Publishing new versions of `anydesk-meb`

1. [Create a new release in GitHub](https://github.com/digabi/anydesk-meb/releases/new)
2. Name the release with the same format as above (`prod-YYYY-MM-DD-BUILDNO`)
3. Create a tag in the release creation UI with the same name
4. Upload the latest `.tar.gz` file as a release asset; if you're not updating AnyDesk, just update the build number when uploading the release asset
5. Publish the release
6. GitHub Actions will build a new release package and upload it as a release asset
7. Follow instructions in the YTL Linux repo to update the AnyDesk deb that is then included in YTL Linux: https://github.com/digabi/ytl-linux#updating-additional-software-components
